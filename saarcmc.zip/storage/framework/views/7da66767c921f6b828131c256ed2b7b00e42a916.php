
<?php $__env->startSection('title', 'Health Workers'); ?>
<?php $__env->startSection('content'); ?>
    <div class="mt-5">
        <h1 class="text-center myHeadings" data-aos="fade-right" data-aos-duration="1500"> Health Workers</h1>
        <!-- Workers Details -->
        <div class="health-workers-div mt-5" data-aos="zoom-out-down" data-aos-duration="1500">
            <div class="health-workers">
                <div class="pic">
                    <img src="/images/doctor1.jpg" alt="" />
                </div>
                <div class="workers-detail">
                    <h3 class="title">Aashish Aryal</h3>
                    <span class="post">Dentist</span>
                </div>
                <ul class="social">
                    <li><a href="" class="fab fa-facebook"></a></li>
                    <li><a href="" class="fab fa-instagram"></a></li>
                    <li><a href="" class="fab fa-twitter"></a></li>
                    <li><a href="" class="fa fa-phone"></a></li>
                </ul>
            </div>
            <div class="health-workers">
                <div class="pic">
                    <img src="/images/doctor1.jpg" alt="" />
                </div>
                <div class="workers-detail">
                    <h3 class="title">Aashish Aryal</h3>
                    <span class="post">Dentist</span>
                </div>
                <ul class="social">
                    <li><a href="" class="fab fa-facebook"></a></li>
                    <li><a href="" class="fab fa-instagram"></a></li>
                    <li><a href="" class="fab fa-twitter"></a></li>
                    <li><a href="" class="fa fa-phone"></a></li>
                </ul>
            </div>
            <div class="health-workers">
                <div class="pic">
                    <img src="/images/doctor2.jpg" alt="" />
                </div>
                <div class="workers-detail">
                    <h3 class="title">Nikesh Bista</h3>
                    <span class="post">ENT Especialist</span>
                </div>
                <ul class="social">
                    <li><a href="" class="fab fa-facebook"></a></li>
                    <li><a href="" class="fab fa-instagram"></a></li>
                    <li><a href="" class="fab fa-twitter"></a></li>
                    <li><a href="" class="fa fa-phone"></a></li>
                </ul>
            </div>
        </div>
        <div class="health-workers-div mt-5" data-aos="zoom-out-up" data-aos-duration="1500">
            <div class="health-workers">
                <div class="pic">
                    <img src="/images/doctor2.jpg" alt="" />
                </div>
                <div class="workers-detail">
                    <h3 class="title">Nikesh Bista</h3>
                    <span class="post">ENT Especialist</span>
                </div>
                <ul class="social">
                    <li><a href="" class="fab fa-facebook"></a></li>
                    <li><a href="" class="fab fa-instagram"></a></li>
                    <li><a href="" class="fab fa-twitter"></a></li>
                    <li><a href="" class="fa fa-phone"></a></li>
                </ul>
            </div>

            <div class="health-workers">
                <div class="pic">
                    <img src="/images/doctor1.jpg" alt="" />
                </div>
                <div class="workers-detail">
                    <h3 class="title">Aashish Aryal</h3>
                    <span class="post">Dentist</span>
                </div>
                <ul class="social">
                    <li><a href="" class="fab fa-facebook"></a></li>
                    <li><a href="" class="fab fa-instagram"></a></li>
                    <li><a href="" class="fab fa-twitter"></a></li>
                    <li><a href="" class="fa fa-phone"></a></li>
                </ul>
            </div>
            <div class="health-workers">
                <div class="pic">
                    <img src="/images/doctor1.jpg" alt="" />
                </div>
                <div class="workers-detail">
                    <h3 class="title">Aashish Aryal</h3>
                    <span class="post">Dentist</span>
                </div>
                <ul class="social">
                    <li><a href="" class="fab fa-facebook"></a></li>
                    <li><a href="" class="fab fa-instagram"></a></li>
                    <li><a href="" class="fab fa-twitter"></a></li>
                    <li><a href="" class="fa fa-phone"></a></li>
                </ul>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\saarcmc\resources\views/pages/healthWorkers.blade.php ENDPATH**/ ?>