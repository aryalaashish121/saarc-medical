
<?php $__env->startSection('title', 'Reset Password'); ?>
<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8 resetPass-div">

                <div class="forgot-pass-image" data-aos="fade-down" data-aos-duration="1000">
                    <img src="/images/forgot-password.jpg" class="pass-image" alt="">
                </div>

                <div class="forgot-pass-content justify-content-center">
                    <h5 class="text-center" style="color: rgba(255, 255, 255, 0.918)">
                        Forgot Your Password?
                        <br>
                        <span style="font-size: 14px; font-weight:500; color: rgba(255, 255, 255, 0.918)"> You can reset
                            your password
                            here. </span>
                    </h5>

                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

                    <form method="POST" action="<?php echo e(route('password.email')); ?>">
                        <?php echo csrf_field(); ?>

                        <div class="input-group mb-3 mt-3">
                            <div class="input-group-append">
                                <span class="input-group-text"><i class="fas fa-at"></i></span>
                            </div>
                            <input type="email" id="email" name="email"
                                class="form-control input_user <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                value="<?php echo e(old('email')); ?>" placeholder="Email" required autocomplete="email">

                            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="d-flex justify-content-center mt-5 login_container">
                            <button type="submit" name="button" class="btn login_btn"> Send Password Reset Link <i
                                    class="fas fa-sign-in-alt ml-2"></i> </button>

                        </div>
                    </form>
                </div>

            </div>
        </div>
    </div>

    <style>
        .resetPass-div {
            min-height: 400px;
            max-width: 400px;
            background: #f39c12;
            margin-top: 70px;
            border-radius: 20px;
            box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);
        }

        .forgot-pass-image {
            margin-left: auto;
            margin-right: auto;
            width: 150px;
            height: 150px;
            margin-top: -70px;
        }

        .pass-image {
            width: 150px;
            height: 150px;
            border: 4px solid blueviolet;
            border-radius: 50%;
            box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);
        }

        .forgot-pass-content {
            margin-top: 20px;
            padding-left: 40px;
            padding-right: 40px;
        }

    </style>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\saarcmc\resources\views/auth/passwords/email.blade.php ENDPATH**/ ?>