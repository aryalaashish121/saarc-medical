
<style>
    .profile-img {
        text-align: center;
    }

    .profile-img .text {
        position: relative;
        overflow: hidden;
        margin-top: -20%;
        width: 50%;
        border: none;
        border-radius: 0;
        font-size: 12px;

    }

    .profile-img .text .acronym {
        position: absolute;

        top: 0;
    }

</style>

<nav class="navbar navbar-expand-lg navbar-light fixed-top">
    <a class="navbar-brand" href="/"><img src="/images/logo_white letter.png" style="width: 60px" height="60px"
            alt=""></a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent"
        aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
        <i class="fa fa-bars"></i></span>
    </button>

    <div class="collapse navbar-collapse" id="navbarSupportedContent">
        <ul class="navbar-nav ml-auto">
            <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle" href="#" id="navbardrop" data-toggle="dropdown">
                    <i class="fas fa-home mr-1"></i> SAARCMC
                </a>
                <div class="dropdown-menu">
                    <a class="dropdown-item" href="<?php echo e(route('about-us')); ?>">About SAARCMC</a>
                    <a class="dropdown-item" href="/">SAARC Charter</a>
                    <a class="dropdown-item" href="/">SAARC Structure</a>
                    <a class="dropdown-item" href="<?php echo e(route('chairman')); ?>">SAARCMC Chairman</a>
                    <a class="dropdown-item" href="/">External SAARCMC Relations</a>

                </div>
            </li>
            <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle" href="#" id="navbardrop" data-toggle="dropdown">
                    <i class="fas fa-clinic-medical mr-1"></i> SAARCMC Hospitals
                </a>
                <div class="dropdown-menu">
                    <a class="dropdown-item" href="/">Afghanistan</a>
                    <a class="dropdown-item" href="/">Bangladesh</a>
                    <a class="dropdown-item" href="/">Bhutan</a>
                    <a class="dropdown-item" href="/">India</a>
                    <a class="dropdown-item" href="/">Maldives</a>
                    <a class="dropdown-item" href="/">Nepal</a>
                    <a class="dropdown-item" href="/">Pakistan</a>
                    <a class="dropdown-item" href="/">Sri Lanka</a>
                </div>
            </li>
            <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle" href="#" id="navbardrop" data-toggle="dropdown">
                    <i class="fas fa-user-tie mr-1"></i> Registered
                </a>
                <div class="dropdown-menu">
                    <a class="dropdown-item" href="<?php echo e(route('health-workers')); ?>">Health Workers</a>
                    <a class="dropdown-item" href="<?php echo e(route('registered-centers')); ?>">Centers</a>
                </div>
            </li>

            <li class="nav-item">
                <a class="nav-link" href="<?php echo e(route('resource')); ?>">
                    <i class="fas fa-toolbox mr-1"></i> Resources
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="<?php echo e(route('contactus')); ?>">
                    <i class="fas fa-phone-alt mr-1"></i> Contact Us</a>
            </li>
        </ul>
        <li class="nav-item dropdown navbar-nav navbar-right">
            <?php if(Auth::user()): ?>
                <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown"
                    aria-haspopup="true" aria-expanded="false">

                    <?php
                    $words = explode(' ', Auth::user()->name);
                    $acronym = '';
                    foreach ($words as $w) {
                        $acronym .= $w[0];
                    }
                    ?>
                    <?php echo e($acronym); ?>

                </a>
            <?php else: ?>
                <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown"
                    aria-haspopup="true" aria-expanded="false">
                    <img src="https://mondoltech.com/wp-content/uploads/2021/05/pngtree-user-vector-avatar-png-image_1541962-removebg-preview.png"
                        class="rounded-circle" width="40" />
                </a>
            <?php endif; ?>
            <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                <?php if(Auth::user()): ?>

                    <a href="<?php echo e(route('user.index')); ?>" class="dropdown-item">
                        Profile
                    </a>
                    <div class="dropdown-divider"></div>
                    
            </div>
        <?php else: ?>

            <a href="<?php echo e(route('login')); ?>" class="btn btn-light" style="border-radius: 20px">Login
                <i class="fas fa-sign-in-alt ml-1"></i>
            </a>

            <?php endif; ?>
        </li>
    </div>
</nav>
<?php /**PATH C:\laragon\www\saarcmc\resources\views/layouts/nav.blade.php ENDPATH**/ ?>