<?php
$checkmembership = App\Models\Member::where('user_id', Auth::user()->id)->first();
Auth::user()->name;
?>

<?php $__env->startSection('content'); ?>
    <div id="app">
        <template>
            <v-app id="inspire">
                <v-main class="grey lighten-3">
                    <v-container>
                        <v-row>
                            <v-col cols="2">
                                <v-sheet rounded="lg">
                                    <v-list color="transparent">
                                        
                                        <v-list-item link exact :to="{ name: 'user.dashboard' }">
                                            <v-list-item-content>
                                                <v-list-item-title>
                                                    <v-icon left color="info"> mdi-view-dashboard </v-icon>
                                                    Dashboard
                                                </v-list-item-title>
                                            </v-list-item-content>
                                        </v-list-item>

                                        <v-list-item link exact :to="{ name: 'user.profile' }">
                                            <v-list-item-content>
                                                <v-list-item-title>
                                                    <?php if(Auth::user()->membership != null): ?>
                                                        <?php if(Auth::user()->membership->is_aproved): ?>
                                                            <v-icon left color="primary">mdi-account-check </v-icon>
                                                        <?php elseif(Auth::user()->membership->is_rejected): ?>
                                                            <v-icon left color="error">mdi-account-minus </v-icon>
                                                        <?php else: ?>
                                                            <v-icon left color="green">mdi-account-clock</v-icon>
                                                        <?php endif; ?>
                                                    <?php else: ?>
                                                        <v-icon left>mdi-account</v-icon>
                                                    <?php endif; ?>
                                                    Profile
                                                </v-list-item-title>
                                            </v-list-item-content>
                                        </v-list-item>
                                        <v-divider class="my-2"></v-divider>
                                        <v-list-item color="grey lighten-4" link
                                            @click="clickLogout('<?php echo e(route('logout')); ?>','<?php echo e(url('/login')); ?>')">

                                            <v-list-item-content>
                                                <v-list-item-title>
                                                    <v-icon left color="error">mdi-logout</v-icon>
                                                    Logout
                                                </v-list-item-title>
                                            </v-list-item-content>
                                        </v-list-item>

                                    </v-list>
                                </v-sheet>
                            </v-col>

                            <v-col>
                                <v-sheet min-height="70vh" rounded="lg">
                                    <!--  -->
                                    <router-view></router-view>
                                </v-sheet>
                            </v-col>
                        </v-row>
                    </v-container>
                </v-main>
            </v-app>
        </template>
    </div>

    <?php echo $__env->make('layouts.fbchat', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<script src="<?php echo e(asset('js/app.js')); ?>" defer></script>

<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\saarcmc\resources\views/user/user.blade.php ENDPATH**/ ?>